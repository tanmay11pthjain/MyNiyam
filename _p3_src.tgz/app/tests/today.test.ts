// The student side, checked where the rules live: logging, the window, the streak and who sees what.
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { sql } from "@/server/db";
import { createProfile, findSanghByCode, joinSangh } from "@/server/onboarding";
import { getHistory, getNiyamStats, getToday, setLog } from "@/server/today";

let n = 0;
const phone = () => `+9196${String(Date.now() % 1e6).padStart(6, "0")}${String(n++ % 100).padStart(2, "0")}`;
let heer: string, shan: string;
let today: string;
const day = async (back: number) => (await sql()<{ d: string }[]>`select (private.local_today() - ${back}::int)::text as d`)[0].d;

beforeAll(async () => {
  heer = (await findSanghByCode("HEER01"))!.id;
  shan = (await findSanghByCode("SHAN01"))!.id;
  today = await day(0);
});
afterAll(async () => { await sql().end(); });

async function member(sanghId = heer) {
  const p = phone();
  const r = await joinSangh(p, sanghId);
  if (r.kind === "closed") throw new Error("closed");
  const prof = await createProfile(r.accountId, p, { name: "Member", relation: "self", consent: false });
  if (!prof.ok) throw new Error("profile");
  return { accountId: r.accountId, profileId: prof.profile.id };
}
const niyamByType = async (type: string) =>
  (await sql()<{ id: string }[]>`select id from public.niyams where sangh_id = ${heer} and type = ${type} and status = 'active' limit 1`)[0].id;

/** Writes an old log directly, as the seed does, with the window check set aside. */
async function oldLog(profileId: string, niyamId: string, back: number) {
  await sql().begin(async (tx) => {
    await tx`alter table public.niyam_logs disable trigger niyam_logs_window`;
    await tx`insert into public.niyam_logs (profile_id, niyam_id, log_date, done) values (${profileId}, ${niyamId}, private.local_today() - ${back}::int, true)`;
    await tx`alter table public.niyam_logs enable trigger niyam_logs_window`;
  });
}

describe("logging", () => {
  it("yes/no: one tap logs, another undoes, and a repeat never counts twice", async () => {
    const m = await member();
    const id = await niyamByType("yesno");
    for (let i = 0; i < 3; i++) await setLog(m.accountId, m.profileId, { niyamId: id, date: today });
    const rows = await sql()`select 1 from public.niyam_logs where profile_id = ${m.profileId} and niyam_id = ${id}`;
    expect(rows).toHaveLength(1);
    const t = await getToday(m.accountId, m.profileId);
    expect(t!.today.niyams.find((x) => x.id === id)!.done).toBe(true);
    await setLog(m.accountId, m.profileId, { niyamId: id, date: today, done: false });
    expect(await sql()`select 1 from public.niyam_logs where profile_id = ${m.profileId}`).toHaveLength(0);
  });

  it("count: a counter with no upper limit; the first one makes it done", async () => {
    const m = await member();
    const id = await niyamByType("count");
    const one = await setLog(m.accountId, m.profileId, { niyamId: id, date: today, value: 1 });
    expect(one.ok && one.niyam).toMatchObject({ value: 1, done: true });
    const many = await setLog(m.accountId, m.profileId, { niyamId: id, date: today, value: 5000 });
    expect(many.ok && many.niyam).toMatchObject({ value: 5000, done: true });
    await setLog(m.accountId, m.profileId, { niyamId: id, date: today, value: 0 });
    expect(await sql()`select 1 from public.niyam_logs where profile_id = ${m.profileId}`).toHaveLength(0);
  });

  it("choice: only the admin's options are accepted", async () => {
    const m = await member();
    const id = await niyamByType("choice");
    expect(await setLog(m.accountId, m.profileId, { niyamId: id, date: today, choice: "feast" })).toEqual({ ok: false, reason: "invalid_choice" });
    const ok = await setLog(m.accountId, m.profileId, { niyamId: id, date: today, choice: "upvas" });
    expect(ok.ok && ok.niyam).toMatchObject({ choice: "upvas", done: true });
  });

  it("a niyam of another sangh is not found", async () => {
    const m = await member(shan);
    const id = await niyamByType("yesno"); // belongs to HEER01
    expect(await setLog(m.accountId, m.profileId, { niyamId: id, date: today })).toEqual({ ok: false, reason: "not_found" });
  });
});

describe("the logging window", () => {
  it("yesterday can be filled in and cleared; two days ago can be neither", async () => {
    const m = await member();
    const id = await niyamByType("yesno");
    expect((await setLog(m.accountId, m.profileId, { niyamId: id, date: await day(1) })).ok).toBe(true);
    expect((await setLog(m.accountId, m.profileId, { niyamId: id, date: await day(1), done: false })).ok).toBe(true);
    expect(await setLog(m.accountId, m.profileId, { niyamId: id, date: await day(2) })).toEqual({ ok: false, reason: "log_window_closed" });
    await oldLog(m.profileId, id, 2);
    expect(await setLog(m.accountId, m.profileId, { niyamId: id, date: await day(2), done: false })).toEqual({ ok: false, reason: "log_window_closed" });
    expect(await sql()`select 1 from public.niyam_logs where profile_id = ${m.profileId}`).toHaveLength(1);
  });

  it("tomorrow is never allowed", async () => {
    const m = await member();
    const id = await niyamByType("yesno");
    expect(await setLog(m.accountId, m.profileId, { niyamId: id, date: await day(-1) })).toEqual({ ok: false, reason: "log_window_closed" });
  });

  it("yesterday stays open by default and closes when the pathshala allows no catch-up", async () => {
    const m = await member();
    const id = await niyamByType("yesno");
    await sql()`update public.sanghs set log_back_hours = 0 where id = ${heer}`;
    try {
      expect(await setLog(m.accountId, m.profileId, { niyamId: id, date: await day(1) })).toEqual({ ok: false, reason: "log_window_closed" });
    } finally {
      await sql()`update public.sanghs set log_back_hours = 24 where id = ${heer}`;
    }
  });
});

describe("streak", () => {
  it("counts days in a row with at least one niyam done", async () => {
    const m = await member();
    const id = await niyamByType("yesno");
    expect((await getToday(m.accountId, m.profileId))!.streak).toBe(0);
    await oldLog(m.profileId, id, 3);
    await oldLog(m.profileId, id, 2);
    expect((await getToday(m.accountId, m.profileId))!.streak).toBe(0); // broken: yesterday and today are empty
    await setLog(m.accountId, m.profileId, { niyamId: id, date: await day(1) });
    expect((await getToday(m.accountId, m.profileId))!.streak).toBe(3);
    await setLog(m.accountId, m.profileId, { niyamId: id, date: today });
    expect((await getToday(m.accountId, m.profileId))!.streak).toBe(4);
  });

  it("one count is enough for the day", async () => {
    const m = await member();
    await setLog(m.accountId, m.profileId, { niyamId: await niyamByType("count"), date: today, value: 1 });
    expect((await getToday(m.accountId, m.profileId))!.streak).toBe(1);
  });

  it("Tej: points per niyam, and each count up to 10 a day", async () => {
    const m = await member();
    const yes = await niyamByType("yesno"), cnt = await niyamByType("count");
    const [{ py }] = await sql()`select points as py from public.niyams where id = ${yes}`;
    const [{ pc }] = await sql()`select points as pc from public.niyams where id = ${cnt}`;
    await setLog(m.accountId, m.profileId, { niyamId: yes, date: today });
    await setLog(m.accountId, m.profileId, { niyamId: cnt, date: today, value: 108 });
    const p = (await getToday(m.accountId, m.profileId))!.progress;
    expect(p.tejToday).toBe(py + 10 * pc);
    expect(p.tej).toBe(p.tejToday);
    const stats = (await getNiyamStats(m.accountId, m.profileId))!;
    expect(stats.find((x) => x.id === cnt)).toMatchObject({ streak: 1, best: 1, total: 108 });
    expect(stats.find((x) => x.id === yes)).toMatchObject({ streak: 1, total: 1, unit: "time kept" });
  });
});

describe("history", () => {
  it("shows the month newest first, up to today, with core counts", async () => {
    const m = await member();
    await setLog(m.accountId, m.profileId, { niyamId: await niyamByType("yesno"), date: today });
    const h = await getHistory(m.accountId, m.profileId, today.slice(0, 7));
    expect(h!.days[0]).toMatchObject({ date: today });
    expect(h!.days[0].anyDone).toBe(1);
    expect(h!.days.every((d, i, a) => i === 0 || d.date < a[i - 1].date)).toBe(true);
  });

  it("removing a person still deletes their logs, whatever the window", async () => {
    const m = await member();
    const id = await niyamByType("yesno");
    await oldLog(m.profileId, id, 5);
    await sql()`delete from public.profiles where id = ${m.profileId}`;
    expect(await sql()`select 1 from public.niyam_logs where profile_id = ${m.profileId}`).toHaveLength(0);
  });
});

describe("sun times on cards", () => {
  it("a Navkarsi niyam shows its time from the sangh's city", async () => {
    const m = await member();
    const [nk] = await sql()`select id from public.niyams where sangh_id = ${heer} and time_hint = 'navkarsi' and status = 'active' limit 1`;
    const t = await getToday(m.accountId, m.profileId);
    expect(t!.today.niyams.find((x) => x.id === nk.id)!.time).toMatch(/^By \d{1,2}:\d{2} am$/);
  });
});

describe("offline taps name their person", () => {
  it("a tap for someone on another number is refused", async () => {
    const a = await member();
    const b = await member();
    const id = await niyamByType("yesno");
    expect(await setLog(a.accountId, b.profileId, { niyamId: id, date: today })).toEqual({ ok: false, reason: "not_found" });
  });
});
